package com.example.backgammon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityEinzelspieler extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_einzelspieler);
    }
}
